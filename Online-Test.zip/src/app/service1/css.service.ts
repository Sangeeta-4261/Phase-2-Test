import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CSSservice {

  constructor(private http : HttpClient) { }

  getQuestionjson(){
    return this.http.get<any>("assets/CSS.json");
  }
}
